------------
Installation
------------

1. Download and install Visual C++ Redistributable Packages for Visual Studio 2015 x86 as well as x64 and DirectX End-User Runtimes (June 2010) **Newer version should work as well**

2. Extract the contents of the zip file to the Devil May Cry 3 root directory, by default this will be "%PROGRAMFILES(X86)%\Steam\SteamApps\common\Devil May Cry 3".

3. Run "install.bat".